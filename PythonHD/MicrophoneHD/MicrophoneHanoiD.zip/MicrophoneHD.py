import serial
import speech_recognition as sr

# Initialize the recognizer
recognizer = sr.Recognizer()

# Define the COM port for your Arduino (change this to match your setup)
arduino_port = "COM3"

# Initialize the Arduino connection
arduino = serial.Serial(arduino_port, 9600)

def start_robot():
    try:
        with sr.Microphone() as source:
            print("Listening for 'robot start' command...")
            recognizer.adjust_for_ambient_noise(source)
            audio = recognizer.listen(source)

        command = recognizer.recognize_google(audio).lower()
        if "robot start" in command:
            print("Starting the robot...")
            arduino.write(b"start\n")  # Send "start" command to Arduino
        else:
            print("Command not recognized.")
    except sr.UnknownValueError:
        print("Could not understand the audio.")
    except sr.RequestError as e:
        print(f"Could not request results; {e}")

if __name__ == "__main__":
    start_robot()


